/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 gameImage gameImage.png 
 * Time-stamp: Friday 07/10/2020, 03:47:52
 * 
 * Image Information
 * -----------------
 * gameImage.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GAMEIMAGE_H
#define GAMEIMAGE_H

extern const unsigned short gameImage[38400];
#define GAMEIMAGE_SIZE 76800
#define GAMEIMAGE_LENGTH 38400
#define GAMEIMAGE_WIDTH 240
#define GAMEIMAGE_HEIGHT 160

#endif

