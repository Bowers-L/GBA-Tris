/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 block block.png 
 * Time-stamp: Friday 07/10/2020, 05:27:56
 * 
 * Image Information
 * -----------------
 * block.png 8@8
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLOCK_H
#define BLOCK_H

extern const unsigned short block[64];
#define BLOCK_SIZE 128
#define BLOCK_LENGTH 64
#define BLOCK_WIDTH 8
#define BLOCK_HEIGHT 8

#endif

